# Startup script for Banking Fraud Detection System

Write-Host "🚀 Starting Anti-Gravity Fraud Detection System..." -ForegroundColor Cyan

# Start Backend in a new window
Write-Host "Starting FastAPI Backend on port 8000..."
Start-Process powershell -ArgumentList "-NoExit", "-Command", "uvicorn backend.main:app --host 0.0.0.0 --port 8000"

# Wait a bit for backend to initialize
Start-Sleep -Seconds 5

# Start Frontend
Write-Host "Starting Streamlit Frontend..."
streamlit run frontend/app.py
