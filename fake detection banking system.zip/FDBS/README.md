# Anti-Gravity Banking Fraud Detection System

An industry-grade, unsupervised machine learning platform for detecting fraudulent banking transactions in real-time.

## 🚀 Features
- **Unsupervised ML Suite**: Isolation Forest, LOF, One-Class SVM, DBSCAN, K-Means, and PyTorch Autoencoders.
- **Anti-Gravity Intelligence Engine**: A custom meta-layer that aggregates multi-model scores and detects behavioral drift.
- **Advanced Analytics**: PCA latent space visualization, geographic heatmaps, and transaction velocity tracking.
- **FastAPI Backend**: Scalable API for data processing, simulation, and model management.
- **Streamlit Dashboard**: Professional, dark-themed UI for security teams.

## 📁 Project Structure
```
FDBS/
├── backend/            # FastAPI server
├── frontend/           # Streamlit UI
├── src/                # Modular logic
│   ├── data_generator.py
│   ├── preprocessing.py
│   ├── models.py
│   └── intelligence_engine.py
├── data/               # Transaction datasets
├── models/             # Persistent model storage
├── requirements.txt
└── README.md
```

## 🛠️ Installation

1. **Clone the repository**:
   ```bash
   cd FDBS
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Generate synthetic data**:
   ```bash
   python src/data_generator.py
   ```

## 🏃 How to Run

### 1. Start the Backend (FastAPI)
In a new terminal:
```bash
uvicorn backend.main:app --reload --port 8000
```

### 2. Start the Frontend (Streamlit)
In another terminal:
```bash
streamlit run frontend/app.py
```

## 🔬 Methodology
The system uses an **unsupervised approach**, meaning it does not require historically labeled fraud data to train. It learns the "normal" pattern of transactions and flags anything that deviates significantly.

The **Anti-Gravity Intelligence Engine** combines:
1. **Reconstruction Error**: From deep autoencoders.
2. **Density Scores**: From LOF and Isolation Forest.
3. **Behavioral Markers**: Sudden changes in transaction amount, frequency, or location (distance from home).

---
*Developed for advanced banking security and portfolio demonstration.*
